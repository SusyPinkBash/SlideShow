#include <stdio.h>
#include <assert.h>
#include "../slideshow.h"

int my_method(unsigned i, unsigned j){
	return (i-j) * (i-j);
}

int main(){
	struct photoset* p = ps_new("test/photoset1.in");

	int s1 = ps_score(p, "0,1,2", my_method);
	int s2 = ps_score(p, "0,3", my_method);
	int s3 = ps_score(p, "0,1,2,3", my_method);

	assert((s1 == 36));
	assert((s2 == 4));
	assert((s3 == s1 + s2));

	ps_delete(p);
}

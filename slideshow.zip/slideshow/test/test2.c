#include <stdio.h>
#include <stdlib.h>
#include "../slideshow.h"

int my_method(unsigned i, unsigned j){
	return (i-j) * (i-j);
}

int main(){
	struct photoset* p[5];
	char filename [64];
	for(int i = 0; i < 5; i++){
		sprintf(filename, "test/photoset%d.in", i + 1);
		p[i] = ps_new(filename);
	}

	for(int i = 0; i < 5; i++){
		ps_delete(p[i]);
	}
}

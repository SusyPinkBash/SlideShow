#include <stdio.h>
#include "../slideshow.h"

int main(){
	struct photoset* p = ps_new("test/photoset1.in");
	ps_delete(p);
}
